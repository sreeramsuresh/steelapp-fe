# Quick Start Guide - Fix 404 Error

## Problem
Payment Reminder modal shows error: `GET http://localhost:5173/api/invoices/25/payment-reminders 404 (Not Found)`

## Root Cause
The backend server is not running on port 5000.

## Solution (3 Steps)

### Step 1: Start PostgreSQL

Open a **NEW terminal** and run:

```bash
sudo service postgresql start
```

Verify it's running:
```bash
sudo service postgresql status
```

You should see: `online`

---

### Step 2: Start Backend Server

Open **ANOTHER terminal** and run:

```bash
cd "/mnt/d/Ultimate Steel/steelapprnp"
node run-migration-031.js
npm run dev
```

**Expected Output:**
```
Running migration 031_create_invoice_payment_reminders.sql...
✓ Migration completed successfully!
Created table: invoice_payment_reminders

> steelapprnp@1.0.0 dev
> nodemon server.js

[nodemon] starting `node server.js`
Server running on port 5000
Database connected successfully
```

Keep this terminal open - the server must stay running!

---

### Step 3: Test the Feature

1. Go back to your browser (http://localhost:5173)
2. Navigate to Invoice List
3. Click the **orange phone icon** on any invoice
4. The modal should now open without errors
5. Add a payment reminder note

---

## Quick Commands (Copy & Paste)

**Terminal 1 - Start PostgreSQL:**
```bash
sudo service postgresql start
```

**Terminal 2 - Start Backend:**
```bash
cd "/mnt/d/Ultimate Steel/steelapprnp" && node run-migration-031.js && npm run dev
```

---

## Troubleshooting

### Migration Error: "relation already exists"
This is OK - it means the migration already ran. Continue to start the server.

### Port 5000 already in use
Kill the existing process:
```bash
lsof -ti:5000 | xargs kill -9
```
Then try starting the backend again.

### Cannot connect to PostgreSQL
Make sure PostgreSQL started successfully:
```bash
sudo service postgresql status
```

If it says "down", start it:
```bash
sudo service postgresql start
```

---

## Verification Checklist

✅ PostgreSQL running: `sudo service postgresql status` shows "online"
✅ Backend running: Terminal shows "Server running on port 5000"
✅ Frontend running: Browser shows app at http://localhost:5173
✅ No 404 errors: Payment reminder modal opens successfully

---

## After Setup

The backend server needs to stay running in the background. You can:
- Keep the terminal open
- Or run it in the background: `npm run dev &`
- Or use a process manager like `pm2`

Each time you restart your computer, you'll need to:
1. Start PostgreSQL
2. Start the backend server
