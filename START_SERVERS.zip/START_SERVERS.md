# How to Start the Application

## Prerequisites
The following errors indicate the database and backend server need to be started:
- `404 (Not Found)` on `/api/invoices/25/payment-reminders`
- `500 (Internal Server Error)` on `/api/account-statements`

## Step-by-Step Instructions

### 1. Start PostgreSQL Database

**Windows WSL:**
```bash
sudo service postgresql start
# Enter your password when prompted
```

**Verify it's running:**
```bash
sudo service postgresql status
```

### 2. Run the Payment Reminders Migration

```bash
cd "/mnt/d/Ultimate Steel/steelapprnp"
node run-migration-031.js
```

Expected output:
```
Running migration 031_create_invoice_payment_reminders.sql...
✓ Migration completed successfully!
Created table: invoice_payment_reminders
```

### 3. Start Backend Server

```bash
cd "/mnt/d/Ultimate Steel/steelapprnp"
npm run dev
# or
node server.js
```

Expected output:
```
Server running on port 5000
Database connected successfully
```

### 4. Verify Frontend is Running

The frontend should already be running on port 5173. If not:

```bash
cd "/mnt/d/Ultimate Steel/steelapp-fe"
npm run dev
```

### 5. Test the Payment Reminder Feature

1. Open browser to http://localhost:5173
2. Navigate to the Invoice List
3. Click the orange **Phone** icon on any invoice
4. The Payment Reminder modal should open
5. Add a new call note with date/time and notes
6. Click "Save Note"

## Common Issues

### Database Connection Refused
**Error:** `ECONNREFUSED 127.0.0.1:5432`
**Fix:** Start PostgreSQL (see step 1)

### 404 on API endpoints
**Error:** `GET http://localhost:5173/api/invoices/25/payment-reminders 404`
**Fix:** Start the backend server (see step 3)

### Migration already exists
**Error:** `relation "invoice_payment_reminders" already exists`
**Fix:** Migration was already run, skip to step 3

## Quick Start (All in one)

```bash
# 1. Start PostgreSQL
sudo service postgresql start

# 2. Run migration (if not done yet)
cd "/mnt/d/Ultimate Steel/steelapprnp"
node run-migration-031.js

# 3. Start backend (in one terminal)
cd "/mnt/d/Ultimate Steel/steelapprnp"
npm run dev

# 4. Start frontend (in another terminal - may already be running)
cd "/mnt/d/Ultimate Steel/steelapp-fe"
npm run dev
```

## Verifying Everything Works

After starting both servers, check:
- Backend: http://localhost:5000 should respond
- Frontend: http://localhost:5173 should load
- No 404 errors in browser console
- Payment reminder modal opens when clicking phone icon
