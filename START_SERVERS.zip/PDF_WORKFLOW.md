# PDF Generation and Storage Workflow

⚠️ **CRITICAL BUSINESS RULE - DO NOT MODIFY WITHOUT EXPLICIT USER APPROVAL** ⚠️

**Last Updated:** 2025-01-08
**Confirmed By:** User

---

## Overview

This document defines the universal workflow for PDF generation, storage, and download across ALL document types in the Ultimate Steel system. These rules ensure legal compliance, data integrity, and consistent user experience.

**Applicable Document Types:**
- Invoices (INV-*)
- Quotations (QUO-*)
- Purchase Orders (PO-*)
- Delivery Notes (DN-*)
- Credit Notes (CN-*)
- Account Statements (STMT-*)

---

## Core Principles

### 1. **Document Immutability**
- **Draft Status:** Documents can be edited freely, PDFs generated on-demand without storage
- **Finalized Status:** Once a document reaches "finalized" status (issued, paid, confirmed, etc.), it becomes **IMMUTABLE**
- **No Versioning:** Each finalized document has exactly ONE PDF - no v1, v2, v3
- **Corrections:** Use Credit Notes for invoice corrections, not editing
- **Audit Trail:** Finalized PDFs must never change to maintain legal compliance

### 2. **Status-Based PDF Handling**

| Document Type | Draft Statuses | Finalized Statuses | Auto-Generate PDF |
|---------------|----------------|-------------------|-------------------|
| Invoice | `draft` | `issued`, `paid`, `overdue`, `partially_paid` | Yes, on status change to finalized |
| Quotation | `draft` | `sent`, `accepted`, `rejected` | Yes, on status change to finalized |
| Purchase Order | `draft` | `confirmed`, `received`, `cancelled` | Yes, on status change to finalized |
| Delivery Note | `draft` | `delivered`, `confirmed` | Yes, on status change to finalized |
| Credit Note | `draft` | `issued`, `applied` | Yes, on status change to finalized |
| Statement | N/A | `generated` | Yes, always generated as finalized |

### 3. **Storage Strategy**

**Draft Documents:**
- ✅ Download allowed (on-demand generation)
- ❌ Storage NOT allowed (no pdf_url saved)
- ✅ Can be downloaded multiple times (freshly generated each time)
- 📝 Use case: Preview before sending to customer

**Finalized Documents:**
- ✅ Auto-generate PDF when status changes to finalized
- ✅ Store permanently in file system
- ✅ Save `pdf_url` and `pdf_generated_at` in database
- ❌ Never regenerate (use stored file)
- 🔒 Immutable for legal/audit compliance

---

## File Organization

### Directory Structure

```
uploads/
├── invoices/
│   ├── customer-{customerId}/
│   │   ├── INV-202501-0001.pdf
│   │   ├── INV-202501-0034.pdf
│   │   └── ...
│   └── customer-{customerId}/
│       └── ...
├── quotations/
│   ├── customer-{customerId}/
│   │   ├── QUO-202501-0001.pdf
│   │   └── ...
│   └── ...
├── purchase_orders/
│   ├── supplier-{supplierId}/
│   │   ├── PO-202501-0001.pdf
│   │   └── ...
│   └── ...
├── delivery_notes/
│   ├── customer-{customerId}/
│   │   ├── DN-202501-0001.pdf
│   │   └── ...
│   └── ...
├── credit_notes/
│   ├── customer-{customerId}/
│   │   ├── CN-202501-0001.pdf
│   │   └── ...
│   └── ...
└── statements/
    ├── customer-{customerId}/
    │   ├── STMT-202501-0001.pdf
    │   └── ...
    └── ...
```

### Path Pattern

```javascript
// For customer-related documents (invoices, quotations, delivery notes, credit notes, statements)
`/uploads/{documentType}/customer-{customerId}/{documentNumber}.pdf`

// For supplier-related documents (purchase orders)
`/uploads/{documentType}/supplier-{supplierId}/{documentNumber}.pdf`
```

### Examples

```
/uploads/invoices/customer-42/INV-202501-0123.pdf
/uploads/quotations/customer-15/QUO-202501-0089.pdf
/uploads/purchase_orders/supplier-7/PO-202501-0056.pdf
/uploads/delivery_notes/customer-42/DN-202501-0045.pdf
/uploads/credit_notes/customer-42/CN-202501-0012.pdf
/uploads/statements/customer-42/STMT-202501-0001.pdf
```

---

## API Endpoint Patterns

### Universal Endpoint Structure

All document types follow this consistent pattern:

```
GET  /api/{documentType}/:id/pdf              # Download PDF (draft or finalized)
POST /api/{documentType}/:id/finalize         # Change status to finalized + auto-generate PDF
GET  /api/{documentType}/:id                  # Get document (includes pdf_url if finalized)
```

### Endpoint Specifications

#### 1. **Download PDF Endpoint**
```
GET /api/{documentType}/:id/pdf
```

**Behavior:**
- **Draft Document:** Generate PDF on-the-fly using Puppeteer, return as blob, do NOT store
- **Finalized Document:** Return stored PDF from file system
- **Response Headers:**
  - `Content-Type: application/pdf`
  - `Content-Disposition: attachment; filename="{documentNumber}.pdf"`

**Implementation:**
```javascript
router.get('/:id/pdf', async (req, res) => {
  const document = await getDocument(req.params.id);

  // If finalized and PDF exists, serve stored file
  if (isFinalized(document) && document.pdf_url) {
    return res.sendFile(path.resolve(document.pdf_url));
  }

  // If draft or no stored PDF, generate on-demand
  const pdfBuffer = await pdfService.generatePDF(document);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${document.number}.pdf"`);
  res.send(pdfBuffer);
});
```

#### 2. **Finalize Document Endpoint**
```
POST /api/{documentType}/:id/finalize
```

**Behavior:**
1. Validate document can be finalized
2. Update status to finalized status
3. Auto-generate PDF using `pdfStorageService.generateAndStore()`
4. Save `pdf_url` and `pdf_generated_at` in database
5. Return updated document with PDF metadata

**Implementation:**
```javascript
router.post('/:id/finalize', async (req, res) => {
  const document = await getDocument(req.params.id);

  // Update status
  await updateStatus(document.id, finalizedStatus);

  // Generate and store PDF
  const { pdf_url, pdf_generated_at } = await pdfStorageService.generateAndStore({
    documentType: 'invoices',
    documentId: document.id,
    documentNumber: document.invoice_number,
    customerId: document.customer_id,
    data: document
  });

  // Update database
  await updatePdfMetadata(document.id, { pdf_url, pdf_generated_at });

  res.json({ success: true, pdf_url, pdf_generated_at });
});
```

---

## Database Schema Patterns

### Required Columns for All Document Tables

All document tables must include these PDF-related columns:

```sql
ALTER TABLE {table_name} ADD COLUMN IF NOT EXISTS pdf_url TEXT;
ALTER TABLE {table_name} ADD COLUMN IF NOT EXISTS pdf_generated_at TIMESTAMPTZ;
```

**Examples:**
- `invoices` → `pdf_url`, `pdf_generated_at`
- `quotations` → `pdf_url`, `pdf_generated_at`
- `purchase_orders` → `pdf_url`, `pdf_generated_at`
- `delivery_notes` → `pdf_url`, `pdf_generated_at`
- `credit_notes` → `pdf_url`, `pdf_generated_at`
- `statements` → `pdf_url`, `pdf_generated_at`

### Column Specifications

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| `pdf_url` | TEXT | YES | Relative path to stored PDF (NULL for drafts) |
| `pdf_generated_at` | TIMESTAMPTZ | YES | Timestamp when PDF was generated and stored (NULL for drafts) |

### Query Patterns

```sql
-- Check if PDF exists for finalized document
SELECT pdf_url, pdf_generated_at
FROM invoices
WHERE id = $1 AND status != 'draft' AND pdf_url IS NOT NULL;

-- Get all documents missing PDFs (finalized but no PDF)
SELECT id, invoice_number, status
FROM invoices
WHERE status != 'draft' AND pdf_url IS NULL;

-- Regenerate missing PDFs for finalized documents (one-time maintenance)
SELECT id, invoice_number, customer_id
FROM invoices
WHERE status IN ('issued', 'paid', 'overdue', 'partially_paid')
  AND pdf_url IS NULL;
```

---

## Logo and Seal Requirements

### Company Settings Schema

Add PDF-specific logo and seal fields to `companies` table:

```sql
ALTER TABLE companies ADD COLUMN IF NOT EXISTS pdf_logo_url TEXT;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS pdf_seal_url TEXT;
```

### File Size Constraints

⚠️ **CRITICAL:** To minimize PDF file sizes, logo and seal images must be optimized:

- **Maximum file size:** 50KB per image
- **Recommended format:** PNG with transparency or optimized JPEG
- **Validation:** Enforce in upload middleware

```javascript
// In upload middleware
const logoUpload = multer({
  storage: multer.diskStorage({
    destination: 'uploads/company-assets/',
    filename: (req, file, cb) => {
      const timestamp = Date.now();
      cb(null, `${timestamp}-${file.originalname}`);
    }
  }),
  limits: { fileSize: 50 * 1024 }, // 50KB
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.match(/image\/(png|jpeg|jpg)/)) {
      return cb(new Error('Only PNG and JPEG images allowed'));
    }
    cb(null, true);
  }
});
```

### PDF Template Integration

```javascript
// In pdfService.js - HTML template
const getCompanyHeader = async () => {
  const company = await getCompanySettings();

  return `
    <div class="company-header">
      ${company.pdf_logo_url ?
        `<img src="file://${path.resolve(company.pdf_logo_url)}"
              class="company-logo"
              style="max-height: 60px; max-width: 150px;" />`
        : ''}
      <div class="company-info">
        <h1>${company.name}</h1>
        <p>${company.address}</p>
      </div>
      ${company.pdf_seal_url ?
        `<img src="file://${path.resolve(company.pdf_seal_url)}"
              class="company-seal"
              style="max-height: 80px; max-width: 80px;" />`
        : ''}
    </div>
  `;
};
```

---

## Code Implementation Patterns

### 1. **PDF Storage Service**

**File:** `steelapprnp/services/pdfStorageService.js`

```javascript
const fs = require('fs').promises;
const path = require('path');
const pdfService = require('./pdfService');

class PDFStorageService {
  /**
   * Generate PDF and store it permanently
   * @param {Object} options - Generation options
   * @param {string} options.documentType - Type of document (invoices, quotations, etc.)
   * @param {number} options.documentId - Document ID
   * @param {string} options.documentNumber - Document number (INV-202501-0001, etc.)
   * @param {number} options.customerId - Customer ID (or supplierId for POs)
   * @param {Object} options.data - Complete document data for PDF generation
   * @returns {Promise<{pdf_url: string, pdf_generated_at: Date}>}
   */
  async generateAndStore({ documentType, documentId, documentNumber, customerId, supplierId, data }) {
    // Determine directory structure
    const entityType = customerId ? 'customer' : 'supplier';
    const entityId = customerId || supplierId;
    const dirPath = path.join(
      __dirname,
      '../uploads',
      documentType,
      `${entityType}-${entityId}`
    );

    // Ensure directory exists
    await fs.mkdir(dirPath, { recursive: true });

    // Generate PDF
    const pdfBuffer = await pdfService.generatePDF(data, documentType);

    // Save file
    const filename = `${documentNumber}.pdf`;
    const filePath = path.join(dirPath, filename);
    await fs.writeFile(filePath, pdfBuffer);

    // Return relative path for database
    const relativePath = `/uploads/${documentType}/${entityType}-${entityId}/${filename}`;

    return {
      pdf_url: relativePath,
      pdf_generated_at: new Date()
    };
  }

  /**
   * Delete stored PDF (use only for cleanup, not for finalized documents)
   */
  async deletePDF(pdfUrl) {
    const fullPath = path.join(__dirname, '..', pdfUrl);
    await fs.unlink(fullPath);
  }
}

module.exports = new PDFStorageService();
```

### 2. **Status Check Helper**

**File:** `steelapprnp/utils/pdfHelpers.js`

```javascript
/**
 * Check if document status is finalized
 * @param {string} documentType - Type of document
 * @param {string} status - Current status
 * @returns {boolean}
 */
function isFinalized(documentType, status) {
  const finalizedStatuses = {
    invoices: ['issued', 'paid', 'overdue', 'partially_paid'],
    quotations: ['sent', 'accepted', 'rejected'],
    purchase_orders: ['confirmed', 'received', 'cancelled'],
    delivery_notes: ['delivered', 'confirmed'],
    credit_notes: ['issued', 'applied'],
    statements: ['generated']
  };

  return finalizedStatuses[documentType]?.includes(status) || false;
}

/**
 * Check if status transition requires PDF generation
 * @param {string} documentType - Type of document
 * @param {string} oldStatus - Previous status
 * @param {string} newStatus - New status
 * @returns {boolean}
 */
function shouldGeneratePDF(documentType, oldStatus, newStatus) {
  // If transitioning from draft to finalized
  const wasDraft = oldStatus === 'draft';
  const isNowFinalized = isFinalized(documentType, newStatus);

  return wasDraft && isNowFinalized;
}

module.exports = {
  isFinalized,
  shouldGeneratePDF
};
```

### 3. **Backend Route Integration**

**Pattern for all document routes:**

```javascript
const pdfStorageService = require('../services/pdfStorageService');
const { isFinalized, shouldGeneratePDF } = require('../utils/pdfHelpers');

// GET /api/invoices/:id/pdf - Download PDF
router.get('/:id/pdf', async (req, res) => {
  try {
    const invoice = await pool.query(
      'SELECT * FROM invoices WHERE id = $1',
      [req.params.id]
    );

    if (invoice.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    const invoiceData = invoice.rows[0];

    // If finalized and PDF exists, serve stored file
    if (isFinalized('invoices', invoiceData.status) && invoiceData.pdf_url) {
      const filePath = path.join(__dirname, '..', invoiceData.pdf_url);
      return res.sendFile(filePath);
    }

    // Generate on-demand for drafts
    const pdfBuffer = await pdfService.generatePDF(invoiceData, 'invoice');
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${invoiceData.invoice_number}.pdf"`);
    res.send(pdfBuffer);

  } catch (error) {
    console.error('Error generating PDF:', error);
    res.status(500).json({ error: 'Failed to generate PDF' });
  }
});

// PATCH /api/invoices/:id/status - Update status (auto-generate PDF if finalizing)
router.patch('/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const invoiceId = req.params.id;

    // Get current invoice
    const current = await pool.query(
      'SELECT * FROM invoices WHERE id = $1',
      [invoiceId]
    );

    if (current.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    const oldStatus = current.rows[0].status;

    // Update status
    await pool.query(
      'UPDATE invoices SET status = $1, updated_at = NOW() WHERE id = $2',
      [status, invoiceId]
    );

    // Auto-generate PDF if transitioning to finalized
    if (shouldGeneratePDF('invoices', oldStatus, status)) {
      const { pdf_url, pdf_generated_at } = await pdfStorageService.generateAndStore({
        documentType: 'invoices',
        documentId: invoiceId,
        documentNumber: current.rows[0].invoice_number,
        customerId: current.rows[0].customer_id,
        data: current.rows[0]
      });

      // Save PDF metadata
      await pool.query(
        'UPDATE invoices SET pdf_url = $1, pdf_generated_at = $2 WHERE id = $3',
        [pdf_url, pdf_generated_at, invoiceId]
      );

      return res.json({
        success: true,
        status,
        pdf_url,
        pdf_generated_at,
        message: 'Invoice finalized and PDF generated'
      });
    }

    res.json({ success: true, status });

  } catch (error) {
    console.error('Error updating status:', error);
    res.status(500).json({ error: 'Failed to update status' });
  }
});
```

### 4. **Frontend Integration**

**Pattern for all document forms:**

```javascript
// InvoiceForm.jsx (and similar for other document types)

const handleDownloadPDF = async () => {
  try {
    setIsGeneratingPDF(true);

    // Use backend endpoint for both draft and finalized
    const { apiClient } = await import('../services/api');
    const response = await apiClient.get(`/invoices/${invoice.id}/pdf`, {
      responseType: 'blob'
    });

    // Download file
    const url = window.URL.createObjectURL(new Blob([response]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${invoice.invoiceNumber}.pdf`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);

  } catch (error) {
    console.error('Error downloading PDF:', error);
    alert('Failed to download PDF');
  } finally {
    setIsGeneratingPDF(false);
  }
};

// When finalizing invoice
const handleFinalizeInvoice = async () => {
  try {
    const { apiClient } = await import('../services/api');

    // Update status to 'issued' (triggers PDF generation)
    await apiClient.patch(`/invoices/${invoice.id}/status`, {
      status: 'issued'
    });

    // Reload invoice to get pdf_url
    const updated = await apiClient.get(`/invoices/${invoice.id}`);
    setInvoice(updated);

    alert('Invoice finalized and PDF generated successfully!');

  } catch (error) {
    console.error('Error finalizing invoice:', error);
    alert('Failed to finalize invoice');
  }
};
```

---

## Document Type Specific Rules

### 1. **Invoices** (`INV-*`)

**Draft Statuses:** `draft`
**Finalized Statuses:** `issued`, `paid`, `overdue`, `partially_paid`

**Special Rules:**
- Issued invoices are IMMUTABLE
- Use Credit Notes (`CN-*`) for corrections, not editing
- PDF must be generated when status changes from `draft` → `issued`
- Storage path: `/uploads/invoices/customer-{customerId}/{invoiceNumber}.pdf`

### 2. **Quotations** (`QUO-*`)

**Draft Statuses:** `draft`
**Finalized Statuses:** `sent`, `accepted`, `rejected`

**Special Rules:**
- PDF generated when status changes to `sent`
- Accepted quotations may be converted to invoices
- Storage path: `/uploads/quotations/customer-{customerId}/{quotationNumber}.pdf`

### 3. **Purchase Orders** (`PO-*`)

**Draft Statuses:** `draft`
**Finalized Statuses:** `confirmed`, `received`, `cancelled`

**Special Rules:**
- POs are supplier-facing documents
- PDF generated when status changes to `confirmed`
- Storage path: `/uploads/purchase_orders/supplier-{supplierId}/{poNumber}.pdf`
- Use `supplierId` instead of `customerId`

### 4. **Delivery Notes** (`DN-*`)

**Draft Statuses:** `draft`
**Finalized Statuses:** `delivered`, `confirmed`

**Special Rules:**
- Often linked to invoices
- PDF generated when status changes to `delivered`
- Storage path: `/uploads/delivery_notes/customer-{customerId}/{dnNumber}.pdf`

### 5. **Credit Notes** (`CN-*`)

**Draft Statuses:** `draft`
**Finalized Statuses:** `issued`, `applied`

**Special Rules:**
- Used for invoice corrections (not editing invoices)
- Must reference original invoice
- PDF generated when status changes to `issued`
- Storage path: `/uploads/credit_notes/customer-{customerId}/{cnNumber}.pdf`

### 6. **Account Statements** (`STMT-*`)

**Draft Statuses:** None (always finalized)
**Finalized Statuses:** `generated`

**Special Rules:**
- Statements are always generated as finalized
- No draft mode
- PDF auto-generated immediately upon creation
- Storage path: `/uploads/statements/customer-{customerId}/{stmtNumber}.pdf`

---

## Migration Checklist

When implementing PDF workflow for a new document type, follow this checklist:

### Database
- [ ] Add `pdf_url TEXT` column
- [ ] Add `pdf_generated_at TIMESTAMPTZ` column
- [ ] Create migration file

### Backend
- [ ] Update route: Add `GET /:id/pdf` endpoint
- [ ] Update route: Add status update logic with PDF auto-generation
- [ ] Update `pdfService.js`: Add document type template
- [ ] Add document type to `pdfHelpers.js` finalized statuses
- [ ] Test draft PDF download (on-demand generation)
- [ ] Test finalized PDF generation (storage)

### Frontend
- [ ] Update form: Add "Download PDF" button
- [ ] Update form: Use backend endpoint (remove client-side generation)
- [ ] Update list: Add bulk download feature
- [ ] Test draft PDF download
- [ ] Test finalized PDF download

### Documentation
- [ ] Update this file with document-specific rules
- [ ] Document any special status transitions
- [ ] Add code examples if behavior differs from standard pattern

---

## Testing Guidelines

### Manual Testing Checklist

For each document type:

#### Draft PDFs
- [ ] Create draft document
- [ ] Click "Download PDF" → PDF generates on-demand
- [ ] Verify PDF NOT saved to database (`pdf_url` is NULL)
- [ ] Download again → Fresh PDF generated
- [ ] Edit document and download → Changes reflected in PDF

#### Finalized PDFs
- [ ] Change status from draft to finalized
- [ ] Verify PDF auto-generated and saved (`pdf_url` populated)
- [ ] Verify `pdf_generated_at` timestamp set
- [ ] Verify file exists at correct path
- [ ] Download PDF → Stored file served (not regenerated)
- [ ] Verify file naming: `{documentNumber}.pdf`
- [ ] Verify folder structure: `customer-{id}` or `supplier-{id}`

#### Logo and Seal
- [ ] Upload logo (<50KB) in Company Settings
- [ ] Upload seal (<50KB) in Company Settings
- [ ] Generate PDF → Logo and seal appear in header
- [ ] Remove logo → PDF generates without logo
- [ ] Attempt to upload >50KB → Upload rejected

#### Bulk Operations
- [ ] Select multiple documents in list
- [ ] Click "Download Selected"
- [ ] Verify all PDFs download correctly
- [ ] Verify draft PDFs generated on-demand
- [ ] Verify finalized PDFs served from storage

---

## Troubleshooting

### Issue: PDF not generating on status change

**Solution:**
1. Check if status transition triggers `shouldGeneratePDF()` helper
2. Verify finalized statuses defined in `pdfHelpers.js`
3. Check backend logs for errors during PDF generation
4. Verify Puppeteer dependencies installed

### Issue: PDF URL returns 404

**Solution:**
1. Verify file exists at path in `pdf_url` column
2. Check directory permissions (755 for folders, 644 for files)
3. Verify path is relative: `/uploads/{type}/customer-{id}/{number}.pdf`
4. Check if `uploads/` directory is served by Express static middleware

### Issue: Logo/seal not appearing in PDF

**Solution:**
1. Verify `pdf_logo_url` and `pdf_seal_url` in database
2. Check file paths are absolute when passed to Puppeteer
3. Verify image files exist and are readable
4. Check Puppeteer HTML template includes `file://` protocol
5. Example: `<img src="file:///absolute/path/to/logo.png" />`

### Issue: PDFs too large

**Solution:**
1. Check logo/seal file sizes (<50KB each)
2. Use PNG with transparency or optimized JPEG
3. Compress images using tools like TinyPNG
4. Verify Puppeteer not rendering at excessive DPI
5. Check PDF generation settings in `pdfService.js`

---

## Security Considerations

### File Access Control
- Serve PDFs through authenticated endpoints only
- Verify user has permission to access document before serving PDF
- Use Express middleware to validate ownership

```javascript
// Middleware example
const verifyDocumentAccess = async (req, res, next) => {
  const userId = req.user.id;
  const documentId = req.params.id;

  const result = await pool.query(
    'SELECT user_id FROM invoices WHERE id = $1',
    [documentId]
  );

  if (result.rows[0]?.user_id !== userId) {
    return res.status(403).json({ error: 'Access denied' });
  }

  next();
};

router.get('/:id/pdf', verifyDocumentAccess, async (req, res) => {
  // ... serve PDF
});
```

### Path Traversal Prevention
- Never use user input directly in file paths
- Validate document IDs from database
- Use `path.resolve()` and `path.join()` to prevent `../` attacks

### File Upload Validation
- Enforce 50KB limit for logo/seal uploads
- Validate MIME types (PNG, JPEG only)
- Sanitize filenames
- Store in secure directory outside web root

---

## Performance Optimization

### Caching Strategy
- **Draft PDFs:** Never cache (always generate fresh)
- **Finalized PDFs:** Cache indefinitely (immutable)
- Use `Cache-Control` headers for finalized PDFs

```javascript
// For finalized PDFs
res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
res.setHeader('ETag', generateETag(pdfUrl));
```

### Bulk Downloads
- Use streams for large files
- Implement queue system for >10 simultaneous downloads
- Consider ZIP archive for bulk downloads (future enhancement)

### Database Queries
- Index `pdf_url` and `pdf_generated_at` columns
- Use EXISTS query to check PDF availability before generation

```sql
-- Add indexes
CREATE INDEX idx_invoices_pdf_url ON invoices(pdf_url);
CREATE INDEX idx_invoices_pdf_generated_at ON invoices(pdf_generated_at);

-- Check if PDF exists
SELECT EXISTS(
  SELECT 1 FROM invoices
  WHERE id = $1 AND pdf_url IS NOT NULL
) AS has_pdf;
```

---

## ⚠️ MODIFICATION POLICY

**DO NOT modify this workflow without explicit user confirmation.**

If you are Claude Code or another AI assistant:
1. **NEVER** change these workflows automatically
2. **ALWAYS** refer to this document before implementing PDF features
3. **ASK** the user explicitly if they want to change the workflow
4. **VERIFY** the user's intent if they request changes
5. **MAINTAIN** immutability principle for legal compliance

If you are a developer:
1. This workflow ensures legal compliance, audit trails, and data integrity
2. Changes require approval from management and legal review
3. Any modifications must update this document first
4. Test thoroughly in non-production environment
5. Consider impact on all 6 document types before making changes

**Critical Rules (NEVER violate):**
- ❌ Do NOT edit finalized invoices (use Credit Notes)
- ❌ Do NOT regenerate stored PDFs (immutable)
- ❌ Do NOT store draft PDFs (waste of storage)
- ❌ Do NOT skip PDF generation on finalization (required for audit)
- ❌ Do NOT allow logo/seal uploads >50KB (bloats PDFs)

---

## Version History

| Date | Changed By | Change Description |
|------|------------|-------------------|
| 2025-01-08 | User | Initial documentation - Universal PDF workflow for all document types |

---

## Quick Reference

### Common Commands

```bash
# Check if PDF exists for invoice
psql -c "SELECT pdf_url, pdf_generated_at FROM invoices WHERE id = 123;"

# Find finalized invoices missing PDFs
psql -c "SELECT id, invoice_number FROM invoices WHERE status != 'draft' AND pdf_url IS NULL;"

# Check logo/seal file sizes
du -h uploads/company-assets/*

# Test PDF generation endpoint
curl -H "Authorization: Bearer TOKEN" \
  http://localhost:3001/api/invoices/123/pdf \
  --output test.pdf

# Count PDFs by document type
find uploads/invoices -name "*.pdf" | wc -l
find uploads/quotations -name "*.pdf" | wc -l
```

### Environment Variables

```bash
# .env
PDF_UPLOAD_DIR=/uploads
PDF_MAX_LOGO_SIZE=51200  # 50KB in bytes
PDF_MAX_SEAL_SIZE=51200  # 50KB in bytes
```

---

**Last reviewed:** 2025-01-08
**Next review:** When implementing new document types or on user request
