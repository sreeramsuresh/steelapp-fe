#!/bin/bash

echo "================================"
echo "System Status Check"
echo "================================"
echo ""

# Check PostgreSQL
echo "1. PostgreSQL Database:"
if sudo service postgresql status > /dev/null 2>&1; then
    echo "   ✓ Running"
else
    echo "   ✗ Not running"
    echo "   → Run: sudo service postgresql start"
fi
echo ""

# Check Backend Server
echo "2. Backend Server (Port 5000):"
if netstat -tuln 2>/dev/null | grep -q ":5000 "; then
    echo "   ✓ Running on port 5000"
else
    echo "   ✗ Not running"
    echo "   → Run: cd steelapprnp && npm run dev"
fi
echo ""

# Check Frontend Server
echo "3. Frontend Server (Port 5173):"
if netstat -tuln 2>/dev/null | grep -q ":5173 "; then
    echo "   ✓ Running on port 5173"
else
    echo "   ✗ Not running"
    echo "   → Run: cd steelapp-fe && npm run dev"
fi
echo ""

# Check Database Connection
echo "4. Database Connection Test:"
cd "/mnt/d/Ultimate Steel/steelapprnp" 2>/dev/null
if [ $? -eq 0 ]; then
    if node -e "const { Pool } = require('pg'); const pool = new Pool({ user: 'postgres', host: 'localhost', database: 'steel_inventory_new', password: 'postgres', port: 5432 }); pool.query('SELECT 1').then(() => { console.log('   ✓ Database reachable'); process.exit(0); }).catch(() => { console.log('   ✗ Database connection failed'); process.exit(1); });" 2>/dev/null; then
        echo ""
    else
        echo ""
    fi
fi

# Check if migration table exists
echo "5. Payment Reminders Table:"
cd "/mnt/d/Ultimate Steel/steelapprnp" 2>/dev/null
if node -e "const { Pool } = require('pg'); const pool = new Pool({ user: 'postgres', host: 'localhost', database: 'steel_inventory_new', password: 'postgres', port: 5432 }); pool.query(\"SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'invoice_payment_reminders')\").then(r => { if(r.rows[0].exists) { console.log('   ✓ Table exists'); } else { console.log('   ✗ Table not found - migration needed'); console.log('   → Run: node run-migration-031.js'); } process.exit(0); }).catch(() => { console.log('   ? Cannot check - database not available'); process.exit(0); });" 2>/dev/null; then
    echo ""
fi

echo "================================"
echo ""
