# Document Naming Conventions

⚠️ **CRITICAL BUSINESS RULE - DO NOT MODIFY WITHOUT EXPLICIT USER APPROVAL** ⚠️

**Last Updated:** 2025-01-07
**Confirmed By:** User

---

## Overview

All document numbers in the Ultimate Steel system follow a standardized format with yearly reset counters. This ensures consistent numbering across all business documents while allowing for year-based organization.

---

## Naming Formats

### 1. **Invoice**
- **Format:** `INV-YYYYMM-NNNN`
- **Example:** `INV-202501-0001`, `INV-202501-0002`, ..., `INV-202512-9999`, `INV-202512-10000`, `INV-202601-0001`
- **Reset:** Counter resets every year (January 1st)
- **Counter Limit:** No upper limit - continues as long as needed throughout the year
- **Pattern Regex:** `^INV-[0-9]{4}[0-9]{2}-[0-9]+$`
- **Counter Query:** Finds highest counter from current year across all months
- **Implementation:** `steelapprnp/routes/invoices.js` (lines 554-587)

### 2. **Purchase Order**
- **Format:** `PO-YYYYMM-NNNN`
- **Example:** `PO-202501-0001`, `PO-202501-0002`, ..., `PO-202512-9999`, `PO-202512-10000`, `PO-202601-0001`
- **Reset:** Counter resets every year (January 1st)
- **Counter Limit:** No upper limit - continues as long as needed throughout the year
- **Pattern Regex:** `^PO-[0-9]{4}[0-9]{2}-[0-9]+$`
- **Counter Query:** Finds highest counter from current year across all months
- **Implementation:** `steelapprnp/routes/purchaseOrders.js` (lines 1033-1054)

### 3. **Quotation**
- **Format:** `QT-YYYYMM-NNNN`
- **Example:** `QT-202501-0001`, `QT-202501-0002`, ..., `QT-202512-9999`, `QT-202512-10000`, `QT-202601-0001`
- **Reset:** Counter resets every year (January 1st)
- **Counter Limit:** No upper limit - continues as long as needed throughout the year
- **Pattern Regex:** `^QT-[0-9]{4}[0-9]{2}-[0-9]+$`
- **Counter Query:** Finds highest counter from current year across all months
- **Implementation:** `steelapprnp/routes/quotations.js` (lines 573-594)

### 4. **Delivery Note**
- **Format:** `DN-YYYYMM-NNNN`
- **Example:** `DN-202501-0001`, `DN-202501-0002`, ..., `DN-202512-9999`, `DN-202512-10000`, `DN-202601-0001`
- **Reset:** Counter resets every year (January 1st)
- **Counter Limit:** No upper limit - continues as long as needed throughout the year
- **Pattern Regex:** `^DN-[0-9]{4}[0-9]{2}-[0-9]+$`
- **Counter Query:** Finds highest counter from current year across all months
- **Implementation:** `steelapprnp/routes/invoices.js` (lines 221-244)

---

## Important Notes

1. **Yearly Reset:** All counters reset to 0001 on January 1st of each year
2. **Not Monthly Reset:** Although the format includes YYYYMM, the counter does NOT reset each month
3. **4-Digit Padding:** All counters use minimum 4-digit padding (0001, 0002, ..., 9999, 10000, 10001, ...)
4. **No Upper Limit:** Counters continue indefinitely throughout the year - there is no maximum
5. **Query Logic:** The SQL queries use regex to find all documents from the current year: `^PREFIX-YYYY[0-9]{2}-[0-9]+$`
6. **Extraction:** Counter is extracted using `CAST(SUBSTRING(number FROM position) AS INTEGER)` where position varies by prefix length

---

## Code Implementation Pattern

```javascript
// Get next document number
const now = new Date();
const currentYear = now.getFullYear();
const currentMonth = String(now.getMonth() + 1).padStart(2, '0');
const yearMonth = `${currentYear}${currentMonth}`;

// Find highest number from current YEAR (not month)
const result = await pool.query(
  `SELECT document_number
   FROM documents
   WHERE document_number ~ '^PREFIX-${currentYear}[0-9]{2}-[0-9]+$'
   ORDER BY CAST(SUBSTRING(document_number FROM position) AS INTEGER) DESC
   LIMIT 1`
);

let nextNumber = 1;
if (result.rows.length > 0) {
  const parts = result.rows[0].document_number.split('-');
  if (parts.length === 3) {
    const lastNumber = parseInt(parts[2]);
    nextNumber = lastNumber + 1;
  }
}

const documentNumber = `PREFIX-${yearMonth}-${nextNumber.toString().padStart(4, '0')}`;
```

---

## ⚠️ MODIFICATION POLICY

**DO NOT modify these naming conventions without explicit user confirmation.**

If you are Claude Code or another AI assistant:
1. **NEVER** change these formats automatically
2. **ALWAYS** refer to this document before making changes
3. **ASK** the user explicitly if they want to change the format
4. **VERIFY** the user's intent if they request changes

If you are a developer:
1. This is a critical business rule that affects accounting, legal compliance, and customer communication
2. Changes require approval from management
3. Any modifications must update this document first
4. Test thoroughly in a non-production environment

---

## Version History

| Date | Changed By | Change Description |
|------|------------|-------------------|
| 2025-01-07 | User | Initial documentation - All formats set to XXX-YYYYMM-NNNN with yearly reset |
